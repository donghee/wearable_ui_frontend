Run with Python 3


Import the simple_actr file to add a command called "python-sum" 
to ACT-R which takes a list of numbers as its only parameter and 
returns the sum of the items in the list.

Here's a sample call:

(evaluate-act-r-command "python-sum" (LIST 1 2 3))