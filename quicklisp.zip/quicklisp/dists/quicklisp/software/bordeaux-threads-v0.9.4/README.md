Bordeaux-Threads is a Common Lisp threading library.

It exposes generic primitives required for synchronization in
multi-threading programming, such as threads, mutexes, semaphores and
condition variables, as well as some atomic operations.

You can read its manual
[here](https://sionescu.github.io/bordeaux-threads/).
