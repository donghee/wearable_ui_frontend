---
date: 2022-01-07T08:00:00Z
title: Threads dictionary
weight: 2
---

##### [Class THREAD](class-thread)

##### [Function THREAD-NAME, THREAD-NATIVE-THREAD](thread-readers)

##### [Function THREADP](threadp)

##### [Function MAKE-THREAD](make-thread)

##### [Variable \*DEFAULT-SPECIAL-BINDINGS\*](default-special-bindings)

##### [Function CURRENT-THREAD, ALL-THREADS](current-all-threads)

##### [Function JOIN-THREAD](join-thread)

##### [Function THREAD-YIELD](thread-yield)

##### [Function START-MULTIPROCESSING](start-multiprocessing)

##### [Function INTERRUPT-THREAD](interrupt-thread)

##### [Function SIGNAL-IN-THREAD, WARN-IN-THREAD, ERROR-IN-THREAD](signal-in-thread)

##### [Function DESTROY-THREAD](destroy-thread)

##### [Function THREAD-ALIVE-P](thread-alive-p)

##### [Condition BORDEAUX-THREADS-ERROR](bordeaux-threads-error)

##### [Condition ABNORMAL-EXIT](abnormal-exit)

##### [Function ABNORMAL-EXIT-CONDITION](abnormal-exit-condition)
