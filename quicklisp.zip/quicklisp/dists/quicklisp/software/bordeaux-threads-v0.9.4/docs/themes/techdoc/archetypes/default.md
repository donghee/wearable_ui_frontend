---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
lastmod: {{ .Date }}
publishdate: {{ .Date }}
description: ""
weight: 10
---

Lorem Ipsum.
